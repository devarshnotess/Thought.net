import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { db } from "@db";
import { posts, comments, messages, contactMessages } from "@db/schema";
import { eq, desc } from "drizzle-orm";
import { WebSocketServer } from "ws";
import { log } from "./vite";

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  const httpServer = createServer(app);
  const wss = new WebSocketServer({ 
    server: httpServer,
    path: "/ws"  // Specify a path for WebSocket connections
  });

  // Handle WebSocket connections
  wss.on("connection", (ws, req) => {
    // Skip Vite HMR connections
    if (req.headers["sec-websocket-protocol"]?.includes("vite-hmr")) {
      return;
    }

    log("New WebSocket connection established");

    ws.on("message", (rawData) => {
      try {
        const data = JSON.parse(rawData.toString());

        // Handle different message types
        switch (data.type) {
          case "new_comment":
            // Broadcast new comments to all clients
            wss.clients.forEach((client) => {
              if (client !== ws && client.readyState === ws.OPEN) {
                client.send(JSON.stringify({
                  type: "comment_update",
                  postId: data.postId
                }));
              }
            });
            break;

          default:
            log(`Unknown message type: ${data.type}`);
        }
      } catch (error) {
        log(`WebSocket message error: ${error}`);
      }
    });

    ws.on("error", (error) => {
      log(`WebSocket error: ${error}`);
    });

    ws.on("close", () => {
      log("WebSocket connection closed");
    });
  });

  // Blog posts
  app.get("/api/posts", async (req, res) => {
    const allPosts = await db.query.posts.findMany({
      orderBy: desc(posts.createdAt),
      with: { author: true },
    });
    res.json(allPosts);
  });

  app.post("/api/posts", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const post = await db.insert(posts).values({
      ...req.body,
      authorId: req.user.id,
    }).returning();
    res.status(201).json(post[0]);
  });

  // Comments
  app.get("/api/posts/:postId/comments", async (req, res) => {
    const postComments = await db.query.comments.findMany({
      where: eq(comments.postId, parseInt(req.params.postId)),
      with: { author: true },
      orderBy: desc(comments.createdAt),
    });
    res.json(postComments);
  });

  app.post("/api/posts/:postId/comments", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const comment = await db.insert(comments).values({
      ...req.body,
      postId: parseInt(req.params.postId),
      authorId: req.user.id,
    }).returning();
    res.status(201).json(comment[0]);
  });

  // Messages
  app.get("/api/messages", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userMessages = await db.query.messages.findMany({
      where: eq(messages.receiverId, req.user.id),
      with: { sender: true },
      orderBy: desc(messages.createdAt),
    });
    res.json(userMessages);
  });

  app.post("/api/messages", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const message = await db.insert(messages).values({
      ...req.body,
      senderId: req.user.id,
    }).returning();
    res.status(201).json(message[0]);
  });

  // Contact form
  app.post("/api/contact", async (req, res) => {
    const message = await db.insert(contactMessages).values(req.body).returning();
    res.status(201).json(message[0]);
  });

  return httpServer;
}