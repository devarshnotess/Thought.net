import { useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { format } from "date-fns";
import type { SelectComment, SelectUser } from "@db/schema";

interface CommentWithAuthor extends SelectComment {
  author: SelectUser;
}

interface CommentSectionProps {
  postId: number;
}

export default function CommentSection({ postId }: CommentSectionProps) {
  const { user } = useAuth();
  const form = useForm<{ content: string }>();
  const wsRef = useRef<WebSocket>();

  useEffect(() => {
    // Only create WebSocket connection if we have a user
    if (!user) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    try {
      wsRef.current = new WebSocket(wsUrl);

      wsRef.current.onopen = () => {
        console.log("WebSocket connected");
      };

      wsRef.current.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === "comment_update" && data.postId === postId) {
            queryClient.invalidateQueries({
              queryKey: ["/api/posts", postId, "comments"],
            });
          }
        } catch (error) {
          console.error("Error parsing WebSocket message:", error);
        }
      };

      wsRef.current.onerror = (error) => {
        console.error("WebSocket error:", error);
      };

      return () => {
        if (wsRef.current?.readyState === WebSocket.OPEN) {
          wsRef.current.close();
        }
      };
    } catch (error) {
      console.error("WebSocket connection error:", error);
    }
  }, [postId, user]);

  const { data: comments = [] } = useQuery<CommentWithAuthor[]>({
    queryKey: ["/api/posts", postId, "comments"],
  });

  const createCommentMutation = useMutation({
    mutationFn: async (data: { content: string }) => {
      const res = await apiRequest(
        "POST",
        `/api/posts/${postId}/comments`,
        data,
      );
      return res.json();
    },
    onSuccess: () => {
      form.reset();
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: "new_comment", postId }));
      }
    },
  });

  const onSubmit = (data: { content: string }) => {
    if (!user) return;
    createCommentMutation.mutate(data);
  };

  if (!user) {
    return null;
  }

  return (
    <div className="space-y-6">
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <Textarea
          placeholder="Write a comment..."
          {...form.register("content", { required: true })}
        />
        <Button
          type="submit"
          disabled={createCommentMutation.isPending}
          className="w-full"
        >
          {createCommentMutation.isPending ? "Posting..." : "Post Comment"}
        </Button>
      </form>

      <div className="space-y-4">
        {comments.map((comment) => (
          <Card key={comment.id}>
            <CardContent className="pt-6">
              <div className="flex gap-4">
                <Avatar className="h-10 w-10">
                  <AvatarImage 
                    src={comment.author.avatar || `https://api.dicebear.com/7.x/avatars/svg?seed=${comment.author.username}`}
                  />
                  <AvatarFallback>{comment.author.username[0]}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-semibold">
                      {comment.author.username}
                    </span>
                    <span className="text-sm text-muted-foreground">
                      {format(new Date(comment.createdAt!), "MMM d, yyyy")}
                    </span>
                  </div>
                  <p>{comment.content}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}