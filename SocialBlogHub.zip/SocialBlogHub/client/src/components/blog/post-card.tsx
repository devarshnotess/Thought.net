import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { format } from "date-fns";
import type { SelectPost, SelectUser } from "@db/schema";

interface PostCardProps {
  post: SelectPost & { author: SelectUser };
}

export default function PostCard({ post }: PostCardProps) {
  const avatarUrl = post.author.avatar || `https://api.dicebear.com/7.x/avatars/svg?seed=${post.author.username}`;

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      {post.imageUrl && (
        <div className="aspect-video w-full overflow-hidden">
          <img
            src={post.imageUrl}
            alt={post.title}
            className="w-full h-full object-cover"
          />
        </div>
      )}
      <CardHeader>
        <div className="flex items-center gap-2 mb-2">
          <Avatar className="h-8 w-8">
            <AvatarImage src={avatarUrl} />
            <AvatarFallback>{post.author.username[0]}</AvatarFallback>
          </Avatar>
          <div className="text-sm text-muted-foreground">
            {post.author.username} •{" "}
            {format(new Date(post.createdAt!), "MMM d, yyyy")}
          </div>
        </div>
        <CardTitle className="line-clamp-2">{post.title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="line-clamp-3 text-muted-foreground">{post.content}</p>
      </CardContent>
    </Card>
  );
}