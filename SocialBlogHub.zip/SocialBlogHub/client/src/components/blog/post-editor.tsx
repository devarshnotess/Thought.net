import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type PostFormData = {
  title: string;
  content: string;
  imageUrl?: string;
};

export default function PostEditor() {
  const { toast } = useToast();
  const form = useForm<PostFormData>();

  const createPostMutation = useMutation({
    mutationFn: async (data: PostFormData) => {
      const res = await apiRequest("POST", "/api/posts", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      form.reset();
      toast({
        title: "Success",
        description: "Post created successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: PostFormData) => {
    createPostMutation.mutate(data);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create New Post</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Input
              placeholder="Title"
              {...form.register("title", { required: true })}
            />
          </div>
          <div>
            <Input
              placeholder="Image URL (optional)"
              {...form.register("imageUrl")}
            />
          </div>
          <div>
            <Textarea
              placeholder="Write your post content..."
              className="min-h-[200px]"
              {...form.register("content", { required: true })}
            />
          </div>
          <Button
            type="submit"
            disabled={createPostMutation.isPending}
            className="w-full"
          >
            {createPostMutation.isPending ? "Publishing..." : "Publish Post"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
