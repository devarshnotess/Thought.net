import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import PostCard from "@/components/blog/post-card";
import PostEditor from "@/components/blog/post-editor";
import { useAuth } from "@/hooks/use-auth";
import type { SelectPost, SelectUser } from "@db/schema";

export default function HomePage() {
  const { user } = useAuth();
  const { data: posts = [] } = useQuery<(SelectPost & { author: SelectUser })[]>({
    queryKey: ["/api/posts"],
  });

  return (
    <div className="space-y-8">
      <h1 className="text-4xl font-bold">Welcome to the Blog</h1>
      
      {user && <PostEditor />}

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {posts.map((post) => (
          <Link key={post.id} href={`/post/${post.id}`}>
            <a className="block">
              <PostCard post={post} />
            </a>
          </Link>
        ))}
      </div>
    </div>
  );
}
