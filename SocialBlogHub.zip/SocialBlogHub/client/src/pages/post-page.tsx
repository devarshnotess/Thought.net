import { useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import CommentSection from "@/components/blog/comment-section";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { format } from "date-fns";
import type { SelectPost, SelectUser } from "@db/schema";

export default function PostPage() {
  const [, params] = useRoute<{ id: string }>("/post/:id");
  const postId = parseInt(params?.id || "0");

  const { data: post } = useQuery<SelectPost & { author: SelectUser }>({
    queryKey: ["/api/posts", postId],
  });

  if (!post) return null;

  const avatarUrl = post.author.avatar || `https://api.dicebear.com/7.x/avatars/svg?seed=${post.author.username}`;

  return (
    <article className="max-w-3xl mx-auto space-y-8">
      {post.imageUrl && (
        <img
          src={post.imageUrl}
          alt={post.title}
          className="w-full aspect-video object-cover rounded-lg"
        />
      )}

      <header className="space-y-4">
        <h1 className="text-4xl font-bold">{post.title}</h1>
        <div className="flex items-center gap-4">
          <Avatar>
            <AvatarImage src={avatarUrl} />
            <AvatarFallback>{post.author.username[0]}</AvatarFallback>
          </Avatar>
          <div>
            <div className="font-medium">{post.author.username}</div>
            <div className="text-sm text-muted-foreground">
              {format(new Date(post.createdAt!), "MMMM d, yyyy")}
            </div>
          </div>
        </div>
      </header>

      <div className="prose prose-lg max-w-none">{post.content}</div>

      <hr className="my-8" />

      <CommentSection postId={postId} />
    </article>
  );
}