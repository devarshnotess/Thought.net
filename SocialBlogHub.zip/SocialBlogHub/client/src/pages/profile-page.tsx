import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import type { SelectMessage, SelectUser } from "@db/schema";

interface MessageWithSender extends SelectMessage {
  sender: SelectUser;
}

export default function ProfilePage() {
  const { user, logoutMutation } = useAuth();
  const { data: messages = [] } = useQuery<MessageWithSender[]>({
    queryKey: ["/api/messages"],
  });

  if (!user) return null;

  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>Profile</CardTitle>
          <CardDescription>Manage your account</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Avatar className="h-20 w-20">
              <AvatarImage
                src={user.avatar || `https://api.dicebear.com/7.x/avatars/svg?seed=${user.username}`}
              />
              <AvatarFallback>{user.username[0]}</AvatarFallback>
            </Avatar>
            <div>
              <h2 className="text-2xl font-bold">{user.username}</h2>
              <p className="text-muted-foreground">
                Member since {format(new Date(user.createdAt!), "MMMM yyyy")}
              </p>
            </div>
          </div>

          <Button
            variant="destructive"
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
          >
            {logoutMutation.isPending ? "Logging out..." : "Logout"}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Messages</CardTitle>
          <CardDescription>Your recent messages</CardDescription>
        </CardHeader>
        <CardContent>
          {messages.length === 0 ? (
            <p className="text-muted-foreground">No messages yet</p>
          ) : (
            <div className="space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className="flex items-start gap-4 p-4 rounded-lg bg-muted"
                >
                  <Avatar>
                    <AvatarImage
                      src={
                        message.sender.avatar ||
                        `https://api.dicebear.com/7.x/avatars/svg?seed=${message.sender.username}`
                      }
                    />
                    <AvatarFallback>{message.sender.username[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex justify-between mb-1">
                      <span className="font-medium">
                        {message.sender.username}
                      </span>
                      <span className="text-sm text-muted-foreground">
                        {format(new Date(message.createdAt!), "MMM d, h:mm a")}
                      </span>
                    </div>
                    <p className="text-sm">{message.content}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}